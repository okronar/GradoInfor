package com.example.roomproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.appcompat.widget.SearchView
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.room.Room
import com.example.database.SuperheroDatabase
import com.example.extra.RetrofitHelper
import com.example.roomproject.databinding.ActivitySuperheroListBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Retrofit

class SuperheroListActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_ID = "extra_id"
    }

    private lateinit var binding: ActivitySuperheroListBinding
    private lateinit var retrofit: Retrofit
    private lateinit var adapter: SuperheroAdapter
    private lateinit var room: SuperheroDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySuperheroListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        retrofit = RetrofitHelper.getRetrofit()

        //iniciar bbdd
        room = Room.databaseBuilder(this, SuperheroDatabase::class.java, "superheroes").fallbackToDestructiveMigration().build()
        getAndSaveSuperheroesData()
        getAndSaveDetailsData()
        initUI()
    }

    private fun initUI(){
        binding.searchView.setOnQueryTextListener(object: SearchView.OnQueryTextListener
        {
            override fun onQueryTextSubmit(query: String?): Boolean {
                searchByName(query.orEmpty())
                return false
            }
            override fun onQueryTextChange(newText: String?) = false
        })
        adapter = SuperheroAdapter { superheroId -> navigateToDetail(superheroId)}
        binding.rvSuperhero.setHasFixedSize(true)
        binding.rvSuperhero.layoutManager = LinearLayoutManager(this)
        binding.rvSuperhero.adapter = adapter
    }

    private fun searchByName(query: String) {
        binding.progressBar.isVisible = true
        CoroutineScope(Dispatchers.IO).launch {
            val superheroes = room.getSuperheroDao().searchSuperheroByName("%$query%")
            runOnUiThread {
                adapter.updateList(superheroes)
                binding.progressBar.isVisible = false
            }
        }
    }

    private fun getAndSaveSuperheroesData() {
        CoroutineScope(Dispatchers.IO).launch {
            room.getSuperheroDao().deleteAllSuperheroes()
            val response = retrofit.create(ApiService::class.java).getSuperheroes()
            if (response.isSuccessful) {
                response.body()?.superheroes?.let { superheroes ->
                    val superheroEntities = superheroes.map { it.toEntity() }
                    room.getSuperheroDao().insertAllSuperheroes(superheroEntities)
                }
            } else {
                Log.e("SuperheroListActivity", "No funciona :( ${response.message()}")
            }
        }
    }

    private fun getAndSaveDetailsData() {
        CoroutineScope(Dispatchers.IO).launch {
            room.getDetailDao().deleteAllDetails()
            val response = retrofit.create(ApiService::class.java).getSuperheroDetail()
            if (response.isSuccessful) {
                response.body()?.stats?.let { details ->
                    val detailEntities = details.map { it.toEntity() }
                    room.getDetailDao().insertAllDetails(detailEntities)
                }
            } else {
                Log.e("SuperheroListActivity", "No funciona :( ${response.message()}")
            }
        }
    }

    private fun navigateToDetail(id: String) {
        val intent = Intent(this, DetailActivity::class.java)
        intent.putExtra(EXTRA_ID, id)
        startActivity(intent)
    }
}