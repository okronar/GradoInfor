package com.example.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.database.entities.DetailEntity

@Dao
interface DetailDao {
    @Query("SELECT * FROM detailsuperhero ORDER BY id DESC")
    suspend fun getAllDetails(): List<DetailEntity>

    @Query("SELECT * FROM detailsuperhero WHERE id LIKE :id")
    suspend fun getDetailById(id: Int): DetailEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllDetails(details: List<DetailEntity>)

    @Query("DELETE FROM detailsuperhero")
    suspend fun deleteAllDetails()
}