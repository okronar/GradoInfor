package com.example.roomproject

import com.example.database.entities.SuperheroEntity
import com.google.gson.annotations.SerializedName

data class SuperHeroDataResponse(
    @SerializedName("response") val response: String,
    @SerializedName("results") val superheroes: List<SuperheroItemResponse>
)
data class SuperheroItemResponse(
    @SerializedName("id") val id: String,
    @SerializedName("name") val name: String,
    @SerializedName("image") val image: SuperheroImageResponse
)
data class SuperheroImageResponse(@SerializedName("url") val url:String)

fun SuperheroItemResponse.toEntity(): SuperheroEntity {
    return SuperheroEntity(
        name = this.name,
        image = this.image.url,
        id = this.id.toInt()
    )
}