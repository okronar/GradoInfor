package com.example.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.database.entities.SuperheroEntity

@Dao
interface SuperheroDao {
    @Query("SELECT * FROM superheroes ORDER BY name DESC")
    suspend fun getAllSuperheroes(): List<SuperheroEntity>

    @Query("SELECT * FROM superheroes WHERE name LIKE :query ORDER BY name DESC")
    suspend fun searchSuperheroByName(query: String): List<SuperheroEntity>

    @Query("SELECT * FROM superheroes WHERE id LIKE :id")
    suspend fun searchSuperheroById(id: Int): SuperheroEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllSuperheroes(superheroes: List<SuperheroEntity>)

    @Query("DELETE FROM superheroes")
    suspend fun deleteAllSuperheroes()
}
