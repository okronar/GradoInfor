package com.example.roomproject

import com.example.database.entities.DetailEntity
import com.example.database.entities.SuperheroEntity
import com.google.gson.annotations.SerializedName

data class SuperHeroDetailResponse(
    @SerializedName("response") val response: String,
    @SerializedName("results") val stats: List<SuperHeroDetailItemResponse>,
)

data class SuperHeroDetailItemResponse(
    @SerializedName("id") val id: String,
    @SerializedName("powerstats") val powerstats: PowerStatsResponse,
    @SerializedName("biography") val biography: Biography
)

data class PowerStatsResponse(
    @SerializedName("intelligence") val intelligence: String,
    @SerializedName("strength") val strength: String,
    @SerializedName("speed") val speed: String,
    @SerializedName("durability") val durability: String,
    @SerializedName("power") val power: String,
    @SerializedName("combat") val combat: String
)

data class Biography(
    @SerializedName("full-name") val fullName: String,
    @SerializedName("publisher") val publisher: String
)

fun SuperHeroDetailItemResponse.toEntity(): DetailEntity {
    return DetailEntity(
        id = this.id.toInt(),
        intelligence = this.powerstats.intelligence,
        strength = this.powerstats.strength,
        speed = this.powerstats.speed,
        durability = this.powerstats.intelligence,
        power = this.powerstats.power,
        combat = this.powerstats.combat,
        fullName = this.biography.fullName,
        publisher = this.biography.publisher
    )
}