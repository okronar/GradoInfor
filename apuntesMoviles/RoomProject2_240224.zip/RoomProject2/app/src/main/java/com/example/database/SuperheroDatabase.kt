package com.example.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.database.dao.DetailDao
import com.example.database.dao.SuperheroDao
import com.example.database.entities.DetailEntity
import com.example.database.entities.SuperheroEntity

@Database(entities = [SuperheroEntity::class, DetailEntity::class], version = 2)
abstract class SuperheroDatabase : RoomDatabase() {
    abstract fun getSuperheroDao(): SuperheroDao
    abstract fun getDetailDao(): DetailDao
}