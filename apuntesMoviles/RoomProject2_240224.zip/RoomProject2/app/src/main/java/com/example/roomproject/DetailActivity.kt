package com.example.roomproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.util.TypedValue
import android.view.View
import androidx.room.Room
import com.example.database.SuperheroDatabase
import com.example.database.entities.DetailEntity
import com.example.database.entities.SuperheroEntity
import com.example.roomproject.SuperheroListActivity.Companion.EXTRA_ID
import com.example.roomproject.databinding.ActivityDetailSuperheroBinding
import com.squareup.picasso.Picasso
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailSuperheroBinding
    private lateinit var database: SuperheroDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailSuperheroBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val id: String = intent.getStringExtra(EXTRA_ID).orEmpty()
        database = Room.databaseBuilder(applicationContext, SuperheroDatabase::class.java, "superheroes").build()
        getSuperheroInformation(id)
    }

    private fun getSuperheroInformation(id: String) {
        CoroutineScope(Dispatchers.IO).launch {
            val superheroDao = database.getSuperheroDao()
            val detailDao = database.getDetailDao()
            val superhero = superheroDao.searchSuperheroById(id.toInt())
            val detail = detailDao.getDetailById(id.toInt())

            Log.d("DetailActivity", "Superhero: $superhero")
            Log.d("DetailActivity", "Detail: $detail")

            if (superhero != null && detail != null) {
                runOnUiThread { createUI(superhero, detail) }
            }
        }
    }

    private fun createUI(superhero: SuperheroEntity, detail: DetailEntity) {
        var img = superhero.image
        Log.d("IMAGEN", "Mas details: $img")
        Picasso.get().load(superhero.image).into(binding.ivSuperhero)
        binding.tvSuperheroName.text = superhero.name
        binding.tvSuperheroRealName.text = detail.fullName
        binding.tvPublisher.text = detail.publisher
        prepareStats(detail)
    }

    private fun prepareStats(detail: DetailEntity) {
        updateHeight(binding.viewIntelligence, detail.intelligence)
        updateHeight(binding.viewStrength, detail.strength)
        updateHeight(binding.viewSpeed, detail.speed)
        updateHeight(binding.viewDurability, detail.durability)
        updateHeight(binding.viewPower, detail.power)
        updateHeight(binding.viewCombat, detail.combat)
    }

    private fun updateHeight(view: View, stat:String){
        val params = view.layoutParams
        if (stat != "null") {
            params.height = pxToDp(stat.toFloat())
        } else {
            params.height = pxToDp(0.toFloat())
        }
        view.layoutParams = params
    }

    private fun pxToDp(px:Float):Int{
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, px, resources.displayMetrics).roundToInt()
    }
}