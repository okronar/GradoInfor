﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBurguerLib
{
    public class Nuggets
    {
        private double precio;

        public Nuggets()
        {
            this.precio = 3;
        }
        public double getPrecio() { return precio; }
    }
}
