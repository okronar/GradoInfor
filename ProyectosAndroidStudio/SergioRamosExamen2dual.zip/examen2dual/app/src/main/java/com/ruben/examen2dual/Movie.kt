package com.ruben.examen2dual

data class Movie (
    val title: String,
    val image: String,
    val director :String,
    val duration: String,
    val releaseDate: String,
    val genre: String

)