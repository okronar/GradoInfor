package com.sergio.aplicacionpmdm.Tarea1

import com.sergio.aplicacionpmdm.BoardGamesApp.GameCategory

data class VerticalObject (val texto: String, var colorFondo: Int)